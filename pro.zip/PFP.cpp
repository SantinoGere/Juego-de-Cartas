#include <iostream>
using namespace std;
#include <cstdlib> // Para rand() y srand()
#include <ctime>   // Para time()
#include "funciones.h"

int main()
{
	srand(static_cast<unsigned int>(time(0)));
	int opcion,puntajeTotal1=0,puntajeTotal2=0,estadisticasPuntajes[100];
	string nombreJugador1,nombreJugador2,ModJuego,estadisticasNombre[100],estadisticasModos[100];
	blanquearEstadisticas(estadisticasNombre);
    while (true)
    {
        system  ("cls");
        cout<< "GREED"<< endl;
        cout<< "-----------------------"<< endl;
        cout<< "1 - MODO UN JUGADOR"<< endl;
        cout<< "2 - MODO DOS JUGADORES"<< endl;
        cout<< "3 - ESTADISTICAS"<< endl;
        cout<< "4 - CREDITOS"<< endl;
        cout<< "-----------------------"<< endl;
        cout<< "0 - SALIR"<< endl;
        cout<< endl;

        cout<< "OPCION: ";
        cin>>opcion;
        system ("cls");

        switch (opcion)
        {
        case 1: //
        	puntajeTotal1=0;
        	ModJuego="1";
        	game1p(puntajeTotal1,nombreJugador1);
        	guardarEstaditicas(puntajeTotal1,nombreJugador1,ModJuego,estadisticasPuntajes,estadisticasNombre,estadisticasModos);
            break;
        case 2: //
        	puntajeTotal1=0;
        	puntajeTotal2=0;
        	ModJuego="2";
        	game2p(puntajeTotal1,puntajeTotal2,nombreJugador1,nombreJugador2);
        	if(puntajeTotal1>=puntajeTotal2){
				guardarEstaditicas(puntajeTotal1,nombreJugador1,ModJuego,estadisticasPuntajes,estadisticasNombre,estadisticasModos);
			}
			else{
				guardarEstaditicas(puntajeTotal2,nombreJugador2,ModJuego,estadisticasPuntajes,estadisticasNombre,estadisticasModos);
			}
            break;
        case 3: //
        	mostrarEstadisticas(estadisticasPuntajes,estadisticasNombre,estadisticasModos);
            break;
        case 4: //
        	Creditos();
            break;
        case 0: cout<<"GRACIAS POR JUGAR."<<endl;
        return 0;
            break;
        default:
            cout<<"ESTA OPCION NO ES CORRECTA, SELECCIONE OTRA."<<endl;

        }
        system ("pause");
    }
    return 0;
}



