#include <iostream>
using namespace std;
#include <cstdlib> // Para rand() y srand()
#include <ctime>   // Para time()

//prototipos
void mostrardados(string *dadosMostrar);
void dibujarDado(int valor,string *dadosMostrar);
void GenerarDados(int *dados,int size);
void limpiarMostrarDados(string *dadosMostrar);
bool compararIguales(int *dadosGame,int cantDadosLanzar);
void sumarPuntaje(int *dadosGame,int *dadosBloqueadores,int& cantDadosLanzar,int& puntaje);
void mostrarDadosPantalla(string *dadosMostrar,int *dadosBloqueadores,int *dadosGame,int& cantDadosLanzar);
void game1p(int& puntajeTotal,string& nombreJugador);
void game2p(int& puntajeTotal1,int& puntajeTotal2,string& nombreJugador1,string& nombreJugador2);
void Creditos();
void blanquearEstadisticas(string *EstP);
void guardarEstaditicas(int puntaje,string nombre,string modo,int *estadisticasPuntajes,string *estadisticasNombre,string *estadisticasModos);
void mostrarEstadisticas(int *estadisticasPuntajes,string *estadisticasNombre,string *estadisticasModos);
//


//muestra los dados en pantalla
void mostrardados(string *dadosMostrar){
	for (int i = 0; i < 7; ++i) {
        cout << dadosMostrar[i]<<"\n";
    }
}

//encargada del dibujo de los dados
void dibujarDado(int valor,string *dadosMostrar) { 
    switch (valor) {
        case 1:
	        	dadosMostrar[0]+="+---------+ ";
	        	dadosMostrar[1]+="|         | ";
	        	dadosMostrar[2]+="|         | ";
	        	dadosMostrar[3]+="|    *    | ";
	        	dadosMostrar[4]+="|         | ";
	        	dadosMostrar[5]+="|         | ";
	        	dadosMostrar[6]+="+---------+ ";
            break;
        case 2:
        		dadosMostrar[0]+="+---------+ ";
	        	dadosMostrar[1]+="|         | ";
	        	dadosMostrar[2]+="|  *      | ";
	        	dadosMostrar[3]+="|         | ";
	        	dadosMostrar[4]+="|      *  | ";
	        	dadosMostrar[5]+="|         | ";
	        	dadosMostrar[6]+="+---------+ ";
			break;
        case 3:
        		dadosMostrar[0]+="+---------+ ";
	        	dadosMostrar[1]+="|         | ";
	        	dadosMostrar[2]+="|  *      | ";
	        	dadosMostrar[3]+="|    *    | ";
	        	dadosMostrar[4]+="|      *  | ";
	        	dadosMostrar[5]+="|         | ";
	        	dadosMostrar[6]+="+---------+ ";
        	break;
        case 4:
            	dadosMostrar[0]+="+---------+ ";
	        	dadosMostrar[1]+="|         | ";
	        	dadosMostrar[2]+="|  *   *  | ";
	        	dadosMostrar[3]+="|         | ";
	        	dadosMostrar[4]+="|  *   *  | ";
	        	dadosMostrar[5]+="|         | ";
	        	dadosMostrar[6]+="+---------+ ";
	        break;
        case 5:
            	dadosMostrar[0]+="+---------+ ";
	        	dadosMostrar[1]+="|         | ";
	        	dadosMostrar[2]+="|  *   *  | ";
	        	dadosMostrar[3]+="|    *    | ";
	        	dadosMostrar[4]+="|  *   *  | ";
	        	dadosMostrar[5]+="|         | ";
	        	dadosMostrar[6]+="+---------+ ";
            break;
        case 6:
            	dadosMostrar[0]+="+---------+ ";
	        	dadosMostrar[1]+="|         | ";
	        	dadosMostrar[2]+="|  *   *  | ";
	        	dadosMostrar[3]+="|  *   *  | ";
	        	dadosMostrar[4]+="|  *   *  | ";
	        	dadosMostrar[5]+="|         | ";
	        	dadosMostrar[6]+="+---------+ ";
            break;
        default:
            cout << "Valor inv�lido\n";
            break;
    }
}

//generador de bloqueadores y los del juego
void GenerarDados(int *dados,int size){
	for (int i = 0; i < size; ++i) {
        dados[i] = (rand() % 6) + 1; // Genera un n�mero entre 1 y 6
    }
}

//limpia los string de los dados para mostrar
void limpiarMostrarDados(string *dadosMostrar){
	dadosMostrar[0]="";
	dadosMostrar[1]="";
	dadosMostrar[2]="";
   	dadosMostrar[3]="";
	dadosMostrar[4]="";
	dadosMostrar[5]="";
	dadosMostrar[6]="";
}

//comparador para ver si los dados en juegos son iguales o no
bool compararIguales(int *dadosGame,int cantDadosLanzar){
	if(cantDadosLanzar<=1){
		return false;
	}
	else{
		for(int i=1;i<cantDadosLanzar;i++){
			if(dadosGame[i] != dadosGame[0]) {
				return false;
			}
		}
	}
	return true;
}

//sumador de puntaje
void sumarPuntaje(int *dadosGame,int *dadosBloqueadores,int& cantDadosLanzar,int& puntaje){
	int cantBloqueados=0,dadosMax=cantDadosLanzar,puntajeIguales=0;
	bool flagIguales;
	for (int i=0;i<dadosMax;i++){
		if(dadosGame[i]!=dadosBloqueadores[0]&&dadosGame[i]!=dadosBloqueadores[1]){
			//cout<<dadosGame[i]<<" ";
			puntaje+=dadosGame[i];
			puntajeIguales+=dadosGame[i];
		}
		else{
			cantBloqueados++;
		}
	}
	flagIguales=compararIguales(dadosGame,cantDadosLanzar);
	if(flagIguales==true){
		cout<<"SON TODOS IGUALES, GANA DOBLE LOS PUNTOS DE ESTA TIRADA\n";
		puntaje+=puntajeIguales;
	}
	dadosMax-=cantBloqueados; //dadosMax=dadosMax-cantBloqueados
	cantDadosLanzar=dadosMax;
}

//encargado de limpiar y mostrar los bloqueadores y los dados del game
void mostrarDadosPantalla(string *dadosMostrar,int *dadosBloqueadores,int *dadosGame,int& cantDadosLanzar){
	limpiarMostrarDados(dadosMostrar);
	int maxDados=cantDadosLanzar;
	cout << "DADOS BLOQUADORES:\n\n";
	for(int i=0;i<2;i++){
		dibujarDado(dadosBloqueadores[i],dadosMostrar);
	}
	mostrardados(dadosMostrar);
	cout << "_______________________________________________________\n";
	cout << "\nDADOS GAME:\n\n";
	limpiarMostrarDados(dadosMostrar);
	for(int i=0;i<maxDados;i++){
		dibujarDado(dadosGame[i],dadosMostrar);
	}
	mostrardados(dadosMostrar);
	cout << "_______________________________________________________\n";
}

//manejo principal de 1 player Game
void game1p(int& puntajeTotal,string& nombreJugador){
	int cantDadosLanzar,puntaje,flagLanzamiento;
	int dadosGame[5],dadosBloqueadores[2];
	bool flagIguales;
	string dadosMostrar[7];
	cout<<"INGRESA NOMBRE DEL JUGADOR: ";
	cin>>nombreJugador;
	system("cls");
	cout<<nombreJugador<<" EMPIEZA EL JUEGO!!! "<<"\n\n";
	for(int i=1;i<4;i++){//i seria las rondas en este caso
		puntaje=0;
		cout<<"RONDA "<<i<<"\n";
		if(i>1){
			cout<<"su puntaje hasta ahora es: "<<puntajeTotal<<"\n";
		}
		cout<<"\nEmpezar?\n";
		cantDadosLanzar=5;
		system("pause");
		system("cls");
		flagLanzamiento=1;
		GenerarDados(dadosBloqueadores,2);//Generar dados bloqueadores
		while(cantDadosLanzar!=0 && flagLanzamiento==1){
			GenerarDados(dadosGame,cantDadosLanzar);//Generar dados de juego
			flagIguales=compararIguales(dadosGame,cantDadosLanzar);//control de igualdad
			mostrarDadosPantalla(dadosMostrar,dadosBloqueadores,dadosGame,cantDadosLanzar);// imprime tanto los dados bloqueadores como los dados de juego
			sumarPuntaje(dadosGame,dadosBloqueadores,cantDadosLanzar,puntaje);//suma el puntaje de tirada
			if(cantDadosLanzar==0){//primero revisamos que no se haya quedado sin dados
				cout<<"Se quedo sin dados\n";
				puntaje=0;
				cout << "PERDIO TODOS LOS PUNTOS DE ESTA RONDA\n";
				system("pause");
			}
			else{
				cout << "su puntaje ronda es " << puntaje<<"\n";
				if(flagIguales==true){//revisamos que no sea doble puntos
					cout<<"AL GANAR DOBLES PUNTOS SE TIRA AUTOMATICAMENTE DE NUEVO";
					system("pause");
				}
				else{
					cout <<"si desea seguis lanzando en esta ronda ingrese 1, sino 0\n";
					cin >>flagLanzamiento;
					while(flagLanzamiento!=0 &&flagLanzamiento!=1){//revisamos que no coloque cualquier cosa
						cout <<"INGRESE NUMERO CORRECTO\n";
						cout <<"si desea seguis lanzando ingrese en esta ronda 1, sino 0\n";
						cin >>flagLanzamiento;
					}
				}
			}
			system("cls");
		}
		puntajeTotal+=puntaje;
	}
	cout<<nombreJugador<<" Su puntaje final fue: "<<puntajeTotal<<"\n";
}

//manejo principal de 2 player Game
void game2p(int& puntajeTotal1,int& puntajeTotal2,string& nombreJugador1,string& nombreJugador2){
	int cantDadosLanzar,puntaje,flagLanzamiento;
	int dadosGame[5],dadosBloqueadores[2];
	bool flagIguales;
	string dadosMostrar[7];
	cout<<"INGRESA NOMBRE DEL JUGADOR 1: ";
	cin>>nombreJugador1;
	system("cls");
	cout<<"INGRESA NOMBRE DEL JUGADOR 2: ";
	cin>>nombreJugador2;
	system("cls");
	cout<<"EMPIEZA EL JUEGO!!! "<<"\n\n";
	for(int i=1;i<4;i++){//i seria las rondas en este caso
		for(int j=0;j<2;j++){
			puntaje=0;
			if(j==0){
				cout<<nombreJugador1<<" !!! ";
			}
			else{
				cout<<nombreJugador2<<" !!! "<<"\n\n";
			}
			cout<<"RONDA "<<i<<"\n";
			if(i>1){
				if(j==0){
					cout<<"su puntaje hasta ahora es: "<<puntajeTotal1<<"\n";
				}
				else{
					cout<<"su puntaje hasta ahora es: "<<puntajeTotal2<<"\n";
				}
			}
			cout<<"\nEmpezar?\n";
			cantDadosLanzar=5;
			system("pause");
			system("cls");
			flagLanzamiento=1;
			GenerarDados(dadosBloqueadores,2);//Generar dados bloqueadores
			while(cantDadosLanzar!=0 && flagLanzamiento==1){
				GenerarDados(dadosGame,cantDadosLanzar);//Generar dados de juego
				flagIguales=compararIguales(dadosGame,cantDadosLanzar);//control de igualdad
				mostrarDadosPantalla(dadosMostrar,dadosBloqueadores,dadosGame,cantDadosLanzar);// imprime tanto los dados bloqueadores como los dados de juego
				sumarPuntaje(dadosGame,dadosBloqueadores,cantDadosLanzar,puntaje);//suma el puntaje de tirada
				if(cantDadosLanzar==0){//primero revisamos que no se haya quedado sin dados
					cout<<"Se quedo sin dados\n";
					puntaje=0;
					cout << "PERDIO TODOS LOS PUNTOS DE ESTA RONDA\n";
					system("pause");
				}
				else{
					cout << "su puntaje ronda es " << puntaje<<"\n";
					if(flagIguales==true){//revisamos que no sea doble puntos
						cout<<"AL GANAR DOBLES PUNTOS SE TIRA AUTOMATICAMENTE DE NUEVO";
						system("pause");
					}
					else{
						cout <<"si desea seguis lanzando en esta ronda ingrese 1, sino 0\n";
						cin >>flagLanzamiento;
						while(flagLanzamiento!=0 &&flagLanzamiento!=1){//revisamos que no coloque cualquier cosa
							cout <<"INGRESE NUMERO CORRECTO\n";
							cout <<"si desea seguis lanzando ingrese en esta ronda 1, sino 0\n";
							cin >>flagLanzamiento;
						}
					}
				}
				system("cls");
			}
			if(j==0){
				puntajeTotal1+=puntaje;
			}
			else{
				puntajeTotal2+=puntaje;
			}
		}
	}
	if(puntajeTotal1==puntajeTotal2){
		cout<<"EMPATE!!!: ";
		nombreJugador1+= " y ";
		nombreJugador1+=nombreJugador2;
		cout<< nombreJugador1<<" ,Su puntaje final fue: "<<puntajeTotal2<<"\n";
		nombreJugador1+= " (EMPATE)";
	}
	else if(puntajeTotal1>puntajeTotal2){
		cout<<"GANADOR!!!: ";
		cout<<nombreJugador1<<" ,Su puntaje final fue: "<<puntajeTotal1<<"\n";
		cout<< "sobre el puntaje de: " <<nombreJugador2<<" Su puntaje final fue: "<<puntajeTotal2<<"\n";
	}
	else{
		cout<<"GANADOR!!!:";
		cout<<nombreJugador2<<" ,Su puntaje final fue: "<<puntajeTotal2<<"\n";
		cout<< "sobre el puntaje de " <<nombreJugador1<<" Su puntaje final fue: "<<puntajeTotal1<<"\n";
	}
	cout << "puntaje j1:"<<puntajeTotal1 <<"\n";
	cout << "puntaje j2:"<<puntajeTotal2 <<"\n";
	
}

void Creditos() {
    // Nombre de fantas�a para el grupo
    cout << "Grupo de Desarrollo: Los Programadores del Futuro" << endl;

    // Listado de legajos con los nombres
    cout << "Listado de Integrantes:" << endl;
    cout << "Legajo: 31447 - Nombre: Santino ,Gerevini" << endl;
    cout << "Legajo: 32065 - Nombre: Camila ,Lopez" << endl;
    cout << "Legajo: 31868 - Nombre: Yuliano Cesar, Markevichi Fener" << endl;
}

void blanquearEstadisticas(string *EstN){
	for(int i=0;i<100;i++){
		EstN[i]="";
	}
}

void guardarEstaditicas(int puntaje,string nombre,string modo,int *estadisticasPuntajes,string *estadisticasNombre,string *estadisticasModos){
	int i=0;
	while(estadisticasNombre[i]!=""){
		i++;
	}
	estadisticasPuntajes[i]=puntaje;
	estadisticasNombre[i]=nombre;
	estadisticasModos[i]=modo;
}

void mostrarEstadisticas(int *estadisticasPuntajes,string *estadisticasNombre,string *estadisticasModos){
	int i=0;
	cout << "PUNTAJES MODO 1 JUGADOR:\n\n";
	while(estadisticasNombre[i]!=""){
		if(estadisticasModos[i]=="1"){
			cout<<"Nombre: "<<estadisticasNombre[i]<<"\n";
			cout<<"Puntaje: "<<estadisticasPuntajes[i]<<"\n\n";
		}
		i++;
	}
	i=0;
	cout << "_______________________________________________________\n\n";
	cout << "PUNTAJES GANADOR MODO 2 JUGADOR:\n\n";
	while(estadisticasNombre[i]!=""){
		if(estadisticasModos[i]=="2"){
			cout<<"Nombre: "<<estadisticasNombre[i]<<"\n";
			cout<<"Puntaje: "<<estadisticasPuntajes[i]<<"\n\n";
		}
		i++;
	}
}
